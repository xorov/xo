#pylint:disable=C0114
import logging
import os
from pyrogram import Client
from pyrogram.errors import RPCError
from pyrogram.errors import BadRequest
# import asyncio
# from pyrogram.errors import FloodWait
# from pyrogram.handlers import MessageHandler
# os.environ['TZ'] = 'Asia/Kolkata'



logging.basicConfig(level=logging.INFO)



bot = Client(
    'bot',
    api_id= 1102570, #get it from https://my.telegram.org/auth
    api_hash="8319bd6fcfc11b0e35ff8ddf4c6e85cf", #get it from https://my.telegram.org/auth
    bot_token="5167943610:AAFTd3VqwZ-Uk4JMSX3VZv7YplqzgeoTfUY", #get it from @Botfather
    plugins=dict(root="plugins"),
    parse_mode="html")


try:
    bot.run()
except Exception as e:
    print(e)
    